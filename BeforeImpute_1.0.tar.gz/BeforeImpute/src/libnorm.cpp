#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

//' A RcppArmadillo implementation for preprocessing (library size normalization)
//'
//' @param D       An (m x n) matrix, m is the number of cells, n is the number of genes
//' @return An (m x n) normalized matrix
// [[Rcpp::export]]
arma::mat lib_norm(arma::mat D){
  arma::colvec Libsize = sum(D,1);
  int scale_factor = median(Libsize);
  return (normalise(D, 1, 1) * scale_factor);
}

#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

//' A RcppArmadillo implementation for calculating affinity matrix
//'
//' @param D       An (m x n) preprocessed matrix, m is the number of cells, n is the number of genes
//' @return An (m x m) affinity matrix
// [[Rcpp::export]]
arma::mat compute_affinity_matrix(arma::mat D, int ka) {
  int m = D.n_rows;
  arma::colvec X =  sum(square(D),1);
  arma::mat A = -2*(D*D.t());
  A.each_col() += X;
  A.each_row() += X.t();
  arma::mat Y = sort(A, "descend", 1);
  arma::colvec sigmasq = Y.col(ka-1);
  for (int i=0; i < m; ++i){
    A.row(i) /= sigmasq(i);
  }
  return exp(-A); 
}

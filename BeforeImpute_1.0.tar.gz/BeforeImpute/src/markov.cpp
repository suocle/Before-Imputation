#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

//' A RcppArmadillo implementation for calculating markov affinity matrix
//'
//' @param A       An (m x m) affinity matrix, m is the number of cells
//' @return An (m x m) markov affinity matrix
// [[Rcpp::export]]
arma::mat compute_markov_affinity_matrix(arma::mat A){
  A = A + A.t();
  return (normalise(A, 1, 1));
}

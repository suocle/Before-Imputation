#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

//' A RcppArmadillo implementation for preprocessing (Dimension reduction via PCA)
//'
//' @param D       An (m x n) library size normalized matrix, m is the number of cells, n is the number of genes
//' @return An (m x n) dimension reduced normalized matrix
// [[Rcpp::export]]
arma::mat fix_PCA(arma::mat D){
  int m = D.n_rows;
  arma::rowvec mu = sum(D,0)/m;
  arma::colvec One;
  One.ones(m);
  arma::mat coeff;
  arma::mat score;
  arma::colvec latent;
  princomp(coeff, score, D);
  arma::mat Xhat = score.cols(0,99) * coeff.cols(0,99).t(); /* Reconstruct matrix using only first k principal components*/
  return(Xhat + One * mu); /* Add back the mean to the centered matrix */
}

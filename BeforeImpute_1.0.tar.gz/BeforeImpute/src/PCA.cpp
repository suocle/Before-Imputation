#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

//' A RcppArmadillo implementation for preprocessing (Dimension reduction via PCA)
//'
//' @param D       An (m x n) library size normalized matrix, m is the number of cells, n is the number of genes
//' @return An (m x n) dimension reduced normalized matrix
// [[Rcpp::export]]
arma::mat PCA(arma::mat D){
  int m = D.n_rows;
  int n = D.n_cols;
  arma::rowvec mu = sum(D,0)/m;
  arma::colvec One;
  One.ones(m); /* Vector of ones */
  arma::mat coeff; /* Eigenvectors */
  arma::mat score; /* PC scores */
  arma::colvec latent; /* Eigenvalues */
  princomp(coeff, score, latent, D); /* Obtain Eigenvectors, PC scores and eigenvalues from PCA */
  arma::rowvec c = cumsum(latent.t());
  c = c/c(n-1); /*Normalize to get cumulative variance explained */
  double var_explained = c(0); /* Variance explained by one principal component */
  int idx = 1;
  while (var_explained < 0.7){ /* retain 70% of variation */
    idx += 1;
    var_explained = c[idx-1];
    if (idx == n){
      break;
    }
  }
  arma::mat Xhat = score.cols(0,idx-1) * coeff.cols(0,idx-1).t(); /* Reconstruct matrix using only first k principal components*/
  return(Xhat + One * mu); /* Add back the mean to the centered reconstructed matrix */
}

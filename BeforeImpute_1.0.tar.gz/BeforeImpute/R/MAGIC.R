#' Computes the two matrices used for MAGIC imputation
#'
#' @param D        A (m x n) matrix to be imputed, m is the number of cells, n is the number of genes
#' @param ka       Integer, the distance of the ka-th nearest neighbor for each cell will be used for building affinity matrix, value of 3 to 10 advised
#' @param t        Integer, diffusion parameter for imputation, value of 6 to 12 advised
#' @param pca      Boolean, optional. If TRUE: Use PCA for dimension reduction in the preprocessing step
#' @param fixed_pc Boolean, optional. If TRUE: Dimension reduction using 100 Principal Components in the preprocessing step, FALSE: Compute the number of Principal Components that give 70% variability in the data
#'
#' @return \code{D}           : The processed (m x n) matrix using MAGIC algorithm ready to be imputed
#' @return \code{M}        : The (m x m) Markov Affinity matrix for imputation
#' @export

MAGIC <- function(D, ka, t, pca = FALSE, fixed_pc = TRUE){
  D <- as.matrix(D)
  col_names <- colnames(D)
  row_names <- rownames(D)
  D <- lib_norm(D)
  n <- nrow(D)
  if (n < 100) { fixed_pc = FALSE }
  if (pca == TRUE) {
    if (fixed_pc == TRUE) {
      D <- fix_PCA(D)
    } else {
      D <- PCA(D)
    }
  }
  A <- compute_affinity_matrix(D, ka)
  M <- compute_markov_affinity_matrix(A)
  colnames(D) <- col_names
  rownames(D) <- row_names
  return(list(D=D,M=M))
}